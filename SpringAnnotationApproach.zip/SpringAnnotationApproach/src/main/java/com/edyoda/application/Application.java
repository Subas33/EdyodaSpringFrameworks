package com.edyoda.application;

import com.edyoda.config.SpringConfig;
import com.edyoda.users.Address;
import com.edyoda.users.Project;
import com.edyoda.users.Team;
import com.edyoda.users.User;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.ArrayList;

public class Application {
    public static void main(String[] args) {


        ArrayList<String> projects = new ArrayList<String>();
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);

        Project project = context.getBean("Project", Project.class);
        projects.add("Spring Project");
        projects.add("React Project");
        project.setSubProjects(projects);

        User Employee1  = context.getBean("Employee", User.class);
        Address employee1Address = context.getBean("Address", Address.class);
        employee1Address.setLine1("Ambetkar Street");
        employee1Address.setLine2("Shivaji Nagar");
        employee1Address.setCity("Mumbai");
        employee1Address.setState("Maharastra");
        employee1Address.setPinCode(998798);
        Employee1.setName("Subash");
        Employee1.setPhone("979986986");
        Employee1.setAddress(employee1Address);
        Employee1.displayInfo();

        User Employee2  = context.getBean("Employee", User.class);
        Address employee2Address = context.getBean("Address", Address.class);
        employee2Address.setLine1("Ghandhi Street");
        employee2Address.setLine2("Nehru Nagar");
        employee2Address.setCity("Bangalore");
        employee2Address.setState("Karnataka");
        employee2Address.setPinCode(778798);
        Employee2.setName("Surya");
        Employee2.setPhone("7779986989");
        Employee2.setAddress(employee2Address);
        Employee2.displayInfo();
    }
}
