package com.edyoda.users;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("Employee")
@Scope("prototype")
public class User {

    private String name;
    private String phone;

    @Autowired
    private Address address;

    @Autowired
    private Team team;


    public User(){
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }



    public User(Address address, Team team){
        this.address = address;
        this.team = team;
    }

    public User(String name,String phone){
        this.name = name;
        this.phone = phone;
    }

    public User(String name,String phone, Address address, Team team){
        this.name = name;
        this.phone = phone;
        this.address = address;
        this.team = team;
    }


    public void displayInfo(){
        System.out.println("-----------------------Employee Info-------------------");
        System.out.println("Employee Name: "+ name);
        System.out.println("Employee Phone: "+ phone);
        address.displayAddress();
        team.displayTeam();
        System.out.println("-------------------------------------------------------");
        System.out.println();
    }


}

