package com.edyoda.users;

import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component("Project")
public class Project {

    private ArrayList<String> subProjects = new ArrayList<String>();

    public ArrayList<String> getSubProjects() {
        return subProjects;
    }

    public void setSubProjects(ArrayList<String> subProjects) {
        this.subProjects = subProjects;
    }

    public void displayProject(){
        System.out.println("List of Sub Projects : "+ subProjects);
    }
}
