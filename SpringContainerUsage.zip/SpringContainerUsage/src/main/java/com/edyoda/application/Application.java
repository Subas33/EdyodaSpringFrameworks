package com.edyoda.application;

import com.edyoda.users.User;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public interface Application {

    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        User Employee1 = context.getBean("Employee", User.class);
        User Employee2 = context.getBean("Employee", User.class);
        Employee1.setName("Subash");
        Employee1.setPhone("89467646984");
        Employee2.setName("Surya");
        Employee2.setPhone("94676469882");
        Employee1.displayInfo();
        Employee2.displayInfo();
    }
}
