package com.edyoda.users;

public class Team {

    private String teamName;
    private int numberOfTeamMembers;
    private Project project;


    public Team(Project project){
        this.project = project;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public int getNumberOfTeamMembers() {
        return numberOfTeamMembers;
    }

    public void setNumberOfTeamMembers(int numberOfTeamMembers) {
        this.numberOfTeamMembers = numberOfTeamMembers;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }


    public void displayTeam(){
        System.out.println("Team Name : "+teamName);
        System.out.println("Number of Team Members : "+numberOfTeamMembers);
        project.displayProject();
    }

}
