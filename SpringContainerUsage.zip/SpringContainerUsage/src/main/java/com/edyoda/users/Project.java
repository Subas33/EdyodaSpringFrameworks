package com.edyoda.users;

import java.util.ArrayList;

public class Project {

    private ArrayList<String> subProjects = new ArrayList<String>();

    public ArrayList<String> getSubProjects() {
        return subProjects;
    }

    public void setSubProjects(ArrayList<String> subProjects) {
        this.subProjects = subProjects;
    }

    public void displayProject(){
        System.out.println("List of Sub Projects : "+ subProjects);
    }
}
